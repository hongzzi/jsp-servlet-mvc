package Controll;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.Service;
import Model.User;

/**
 * Servlet implementation class Join
 */
@WebServlet("/Join")
public class Join extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String id, name, pw, email, email_dns, phone_1, phone_2, phone_3;
	private String type;
	
	private File file;
	private FileWriter output;
	private BufferedWriter bw;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Join() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Service service = new Service();
		User user = new User();
		
		type= request.getParameter("type");
		  name = request.getParameter("name");
		   id = request.getParameter("id");
		   pw = request.getParameter("pw");		
		    email = request.getParameter("email");
		    email_dns = request.getParameter("email_dns");		    
		    email = email+"@"+email_dns;		    
		    phone_1 = request.getParameter("phone_1");
		    phone_2 = request.getParameter("phone_2");
		    phone_3 = request.getParameter("phone_3");		    
		    phone_1 = phone_1 +phone_2+phone_3;
		
		
	
		user.setId(id);
		user.setPw(pw);
		
		
		int rst;
		
		rst = service.insertUser(user);
		
		
		  
	}

}
