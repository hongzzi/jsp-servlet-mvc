package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.mysql.jdbc.ResultSetMetaData;

import Controll.ConnUtil;
import Model.List;
import Model.User;

public class Service {
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	public int login(String userID, String userPassword) {
		
		String SQL = "SELECT userPassword FROM USER WHERE userID = ?";
		
		
		try{
			conn = ConnUtil.getConnection();
			
			ps = conn.prepareStatement(SQL);
			ps.setString(1, userID);
			
			rs = ps.executeQuery();
			if(rs.next()) {
				if(rs.getString(1).equals(userPassword)){
					return 1; 
				}
				else
					return 0;
			}
			return -1; 
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -2; //�뜲�씠�꽣踰좎씠�뒪 �삤瑜�
	}
	
	public int insertUser(User user){
		String SQL = "INSERT INTO USER VALUES (?, ?, ?, ?, ?,?,?,?)";
		try{
			conn = ConnUtil.getConnection();
			
			ps = conn.prepareStatement(SQL);
			ps.setString(1, user.getId());
			ps.setString(2, user.getPw());
			ps.setString(3, user.getName());
			ps.setString(4, user.getNick());
			ps.setString(5, user.getPhone());
			ps.setString(6, user.getEmail());
			ps.setString(7, user.getFavorite());
			ps.setInt(8, user.getGender());
		
			return ps.executeUpdate();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return -1;	
	}
	
	// 회원가입

	// 사용가능한 아이디 체크 유무
	public int availableCheck(String id){
			
		return -1;
	}
	
	// 로그인 체크
	// 아이디 존재유무, 비밀번호 일치 유무, 성공
	public int loginCheck(String id, String pw){
		
		return -1;
		
	}
	
	//아이디 찾기
	public String findId(String name, String identity){
		String id = null;
		
		return id;
		
	}
	
	//비밀번호 재설정
	public int resetPw(){
		
		return -1;
	}
	
	// 개인정보 가져오기
	public User getUserInfo(){
		User user = new User();
		
		return user;
	}
	// 개인정보수정
	public int updateUserInfo(User user){
		return -1;
	}
	// 회원탈퇴
	public int deleteUser(String id){
		return -1;
	}
	// 찜목록, 구매목록 가져오기
	public List getListInfo(String id){
		List list = new List();
		
		return list;
	}
	// 나의 블로그 목록
	public 	ArrayList<Blog> getBlogInfo(String id){
		
		ArrayList<Blog> list = new ArrayList<Blog>();
		return list;
	}
	// 블로그 하나
	public Blog getBlogInfo(){
		Blog blog = new Blog();
		return blog;
	}
	
	// 블로그 전체
	public ArrayList<Blog> getAllBlogInfo(){
		
		ArrayList<Blog> list = new ArrayList<Blog>();
		return list;
	}
	// 블로그 댓글 전체 가져오기
	public ArrayList<Comment> getAllComment(int blogNo){
		ArrayList<Comment> list = new ArrayList<Comment>();
		return list;
		
	}

	//책정보 하나 가져오기
	public  Book getAllBook(int no){
		Book book = new Book();
		return book;
	}
	
	//책정보 모두 가져오기
	public  ArrayList<Book> getAllBook(){
		ArrayList<Book> list = new ArrayList<Book>();
		return list;
	}
	
	// 책정보 추가
	public int insertBook(Book book){
		
		return -1;
	}
	
	// 책정보 삭제
	public int deleteBook(String title){
			
		return -1;
	}
	
	// 책정보 수정
	public int updateBook(Book book){
		return -1;
	}
	
	//블로그 신고하기
	public int reportBlog(Report report){
		return -1;
	}
	
	// 신고 목록 전체
	public ArrayList<Report> getAllReport(){
		ArrayList<Report> list = new ArrayList<Report>();
		return list;
	}
	
	public ArrayList<CategoryForBook> getAllCateory(){
		
		ArrayList<CategoryForBook> list = new ArrayList<CategoryForBook>();
		
		try {
			conn = ConnUtil.getConnection();	
			String sql = "select * from CategoryForBook";
			ps = conn.prepareStatement(sql);	
			rs = ps.executeQuery();
			
	
			while(rs.next()){
				
				CategoryForBook cfb = new CategoryForBook();
				
				cfb.setNo(rs.getInt("no"));
				cfb.setTitle(rs.getString("title"));
				
				list.add(cfb);
			
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnUtil.close(conn, ps);
		}
		
		return list;
		
	}
	
	public void getAllCategory_(int category, CategoryForBook list){
		
		int i = 0;
		
		//System.out.println(category);
		
		try {
			conn = ConnUtil.getConnection();	
			String sql = "select * from CategoryForBook_ where p_category=?";
			//String sql = "select count(*) from CategoryForBook_ where p_category=?";
			ps = conn.prepareStatement(sql);	
			ps.setInt(1, category);
			rs = ps.executeQuery();
			rs.last();
			int count = rs.getRow();
			rs.beforeFirst();
			
			//System.out.println("count"+count);
			//System.out.println("category"+category);
			//System.out.println(rs.getString("title"));
			
			String tmp[] = new String[count];
			while(rs.next()){
				tmp[i] = rs.getString("title");
				i++;
			}
			list.setCtitle(tmp);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			ConnUtil.close(conn, ps);
		}
		
		
		
	}
	

	
}
