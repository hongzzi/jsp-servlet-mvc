package Model;

public class List {
	private String[] buylist;
	private String[] cartlist;
	public String[] getBuylist() {
		return buylist;
	}
	public void setBuylist(String[] buylist) {
		this.buylist = buylist;
	}
	public String[] getCartlist() {
		return cartlist;
	}
	public void setCartlist(String[] cartlist) {
		this.cartlist = cartlist;
	}
}
